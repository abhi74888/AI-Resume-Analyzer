# AI Resume Analyzer

A local web application that analyzes resumes and provides AI-powered feedback for job applicants.

## Features

- 📄 Resume upload and analysis
- 🤖 AI-powered feedback and suggestions
- 🎯 Job description matching
- 📊 ATS optimization scoring
- 🔧 Skills gap analysis
- 💾 Local data storage
- 🎨 Responsive design

## Setup Instructions

1. **Install Node.js** (if not already installed)
   - Download from: https://nodejs.org/

2. **Install dependencies**
   ```bash
   cd server
   npm install