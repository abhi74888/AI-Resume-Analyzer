const express = require('express');
const multer = require('multer');
const path = require('path');
const cors = require('cors');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = path.join(__dirname, '../uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + '-' + file.originalname);
  }
});

const upload = multer({
  storage: storage,
  fileFilter: function (req, file, cb) {
    const allowedTypes = ['.pdf', '.doc', '.docx', '.txt'];
    const fileExt = path.extname(file.originalname).toLowerCase();
    if (allowedTypes.includes(fileExt)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only PDF, DOC, DOCX, and TXT files are allowed.'));
    }
  },
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  }
});

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Analysis endpoint
app.post('/api/analyze', upload.single('resume'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        error: 'No file uploaded'
      });
    }

    const jobDescription = req.body.jobDescription || '';
    
    // Simulate AI analysis (replace with actual AI service in production)
    const analysisResult = performAIAnalysis(req.file, jobDescription);
    
    // Clean up uploaded file after analysis
    fs.unlinkSync(req.file.path);
    
    res.json({
      success: true,
      ...analysisResult
    });
    
  } catch (error) {
    console.error('Analysis error:', error);
    res.status(500).json({
      success: false,
      error: 'Analysis failed: ' + error.message
    });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'Resume Analyzer API is running' });
});

function performAIAnalysis(file, jobDescription) {
  // This is a simulation - in a real app, integrate with AI services
  const skillsKeywords = [
    'javascript', 'python', 'java', 'react', 'node', 'html', 'css',
    'sql', 'mongodb', 'aws', 'docker', 'kubernetes', 'git', 'agile',
    'machine learning', 'ai', 'data analysis', 'project management'
  ];
  
  const detectedSkills = skillsKeywords
    .filter(skill => Math.random() > 0.6) // Random selection for demo
    .map(skill => skill.charAt(0).toUpperCase() + skill.slice(1));
  
  const missingSkills = skillsKeywords
    .filter(skill => !detectedSkills.map(s => s.toLowerCase()).includes(skill))
    .slice(0, 4)
    .map(skill => skill.charAt(0).toUpperCase() + skill.slice(1));
  
  // Calculate scores based on various factors
  const baseScore = Math.floor(Math.random() * 30) + 65; // 65-95
  const atsScore = Math.floor(Math.random() * 25) + 70; // 70-95
  const contentScore = Math.floor(Math.random() * 25) + 70; // 70-95
  
  let jobMatchScore = 75;
  let jobMatchFeedback = "Good general alignment with technical roles";
  
  if (jobDescription) {
    const descLower = jobDescription.toLowerCase();
    const relevantKeywords = skillsKeywords.filter(keyword => 
      descLower.includes(keyword)
    );
    jobMatchScore = Math.min(95, 60 + (relevantKeywords.length * 5));
    
    if (relevantKeywords.length > 6) {
      jobMatchFeedback = "Excellent alignment with job requirements";
    } else if (relevantKeywords.length > 3) {
      jobMatchFeedback = "Good alignment with job requirements";
    } else {
      jobMatchFeedback = "Consider tailoring your resume to match the job description better";
    }
  }
  
  return {
    overallScore: baseScore,
    scoreFeedback: getScoreFeedback(baseScore),
    atsScore: atsScore,
    contentScore: contentScore,
    jobMatch: {
      score: jobMatchScore,
      feedback: jobMatchFeedback,
      suggestions: generateJobSuggestions(jobDescription, detectedSkills)
    },
    skills: {
      detected: detectedSkills,
      missing: missingSkills
    },
    suggestions: generateSuggestions(baseScore, detectedSkills.length)
  };
}

function getScoreFeedback(score) {
  if (score >= 90) return "Excellent resume! Ready for top opportunities";
  if (score >= 80) return "Strong resume with minor improvements needed";
  if (score >= 70) return "Good resume with room for enhancement";
  return "Needs significant improvements to be competitive";
}

function generateSuggestions(score, skillsCount) {
  const suggestions = [];
  
  if (score < 80) {
    suggestions.push("Add more quantifiable achievements with metrics");
  }
  
  if (skillsCount < 8) {
    suggestions.push("Include more technical skills and certifications");
  }
  
  suggestions.push(
    "Use action verbs to start bullet points",
    "Ensure consistent formatting throughout",
    "Include relevant keywords for ATS systems",
    "Add a professional summary at the top"
  );
  
  return suggestions.slice(0, 4);
}

function generateJobSuggestions(jobDescription, skills) {
  if (!jobDescription) return [];
  
  const suggestions = [];
  const descLower = jobDescription.toLowerCase();
  
  if (descLower.includes('manager') && !skills.some(s => s.toLowerCase().includes('manager'))) {
    suggestions.push("Highlight leadership and project management experience");
  }
  
  if (descLower.includes('cloud') && !skills.some(s => s.toLowerCase().includes('aws') || s.toLowerCase().includes('azure'))) {
    suggestions.push("Consider adding cloud platform experience if relevant");
  }
  
  if (descLower.includes('ai') && !skills.some(s => s.toLowerCase().includes('machine') || s.toLowerCase().includes('ai'))) {
    suggestions.push("Mention any AI or machine learning experience");
  }
  
  return suggestions;
}

app.listen(PORT, () => {
  console.log(`🚀 Resume Analyzer server running on http://localhost:${PORT}`);
  console.log(`📁 Static files served from: ${path.join(__dirname, '../public')}`);
  console.log(`💾 Uploads directory: ${path.join(__dirname, '../uploads')}`);
});