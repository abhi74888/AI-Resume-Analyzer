// Resume Analyzer Application
class ResumeAnalyzer {
    constructor() {
        this.initializeApp();
    }

    initializeApp() {
        this.uploadArea = document.getElementById('uploadArea');
        this.resumeUpload = document.getElementById('resumeUpload');
        this.analyzeBtn = document.getElementById('analyzeBtn');
        this.analysisPlaceholder = document.getElementById('analysisPlaceholder');
        this.analysisResults = document.getElementById('analysisResults');
        this.jobDescription = document.getElementById('jobDescription');
        this.uploadStatus = document.getElementById('uploadStatus');

        this.bindEvents();
        this.loadSavedData();
    }

    bindEvents() {
        // File upload handling
        this.uploadArea.addEventListener('click', () => this.resumeUpload.click());
        
        this.uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            this.uploadArea.classList.add('dragover');
        });
        
        this.uploadArea.addEventListener('dragleave', () => {
            this.uploadArea.classList.remove('dragover');
        });
        
        this.uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            this.uploadArea.classList.remove('dragover');
            
            if (e.dataTransfer.files.length) {
                this.resumeUpload.files = e.dataTransfer.files;
                this.handleFileSelect();
            }
        });

        this.resumeUpload.addEventListener('change', () => this.handleFileSelect());
        this.analyzeBtn.addEventListener('click', () => this.analyzeResume());
        this.jobDescription.addEventListener('input', () => this.saveJobDescription());
    }

    handleFileSelect() {
        if (this.resumeUpload.files.length) {
            const file = this.resumeUpload.files[0];
            
            // Validate file type
            const allowedTypes = ['.pdf', '.doc', '.docx', '.txt'];
            const fileExt = '.' + file.name.split('.').pop().toLowerCase();
            
            if (!allowedTypes.includes(fileExt)) {
                this.showUploadStatus('Please select a PDF, DOC, DOCX, or TXT file.', 'error');
                this.analyzeBtn.disabled = true;
                return;
            }
            
            // Validate file size (5MB)
            if (file.size > 5 * 1024 * 1024) {
                this.showUploadStatus('File size must be less than 5MB.', 'error');
                this.analyzeBtn.disabled = true;
                return;
            }
            
            this.updateUploadArea(file.name);
            this.showUploadStatus('File ready for analysis!', 'success');
            this.analyzeBtn.disabled = false;
        }
    }

    updateUploadArea(fileName) {
        this.uploadArea.innerHTML = `
            <div class="upload-icon">📄</div>
            <p class="upload-text">${this.escapeHtml(fileName)}</p>
            <p class="file-types">Click to change file</p>
        `;
    }

    showUploadStatus(message, type) {
        this.uploadStatus.textContent = message;
        this.uploadStatus.className = `upload-status ${type}`;
    }

    async analyzeResume() {
        if (!this.resumeUpload.files.length) return;

        const file = this.resumeUpload.files[0];
        const formData = new FormData();
        formData.append('resume', file);
        formData.append('jobDescription', this.jobDescription.value);

        this.setLoadingState(true);

        try {
            const response = await fetch('/api/analyze', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.success) {
                this.displayAnalysisResults(result);
                this.saveAnalysisHistory(result);
            } else {
                throw new Error(result.error || 'Analysis failed');
            }
        } catch (error) {
            console.error('Analysis error:', error);
            this.showError('Analysis failed: ' + error.message);
        } finally {
            this.setLoadingState(false);
        }
    }

    setLoadingState(loading) {
        if (loading) {
            this.analyzeBtn.disabled = true;
            this.analyzeBtn.classList.add('btn-loading');
            this.analyzeBtn.textContent = 'Analyzing...';
        } else {
            this.analyzeBtn.disabled = false;
            this.analyzeBtn.classList.remove('btn-loading');
            this.analyzeBtn.textContent = 'Analyze Resume';
        }
    }

    displayAnalysisResults(data) {
        this.analysisPlaceholder.style.display = 'none';
        this.analysisResults.style.display = 'block';

        this.analysisResults.innerHTML = this.generateResultsHTML(data);
    }

    generateResultsHTML(data) {
        return `
            <div class="score-card">
                <div class="score-label">Overall Resume Score</div>
                <div class="score-value">${data.overallScore}/100</div>
                <div class="score-label">${data.scoreFeedback}</div>
            </div>
            
            <div class="analysis-category">
                <h3 class="category-title">
                    <span class="category-icon">✅</span>
                    ATS Optimization
                </h3>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${data.atsScore}%"></div>
                </div>
                <p>Your resume is ${data.atsScore}% optimized for Applicant Tracking Systems</p>
            </div>
            
            <div class="analysis-category">
                <h3 class="category-title">
                    <span class="category-icon">💼</span>
                    Content Quality
                </h3>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${data.contentScore}%"></div>
                </div>
                <p>Content quality score: ${data.contentScore}%</p>
                <ul class="suggestion-list">
                    ${data.suggestions.map(suggestion => 
                        `<li class="suggestion-item">${this.escapeHtml(suggestion)}</li>`
                    ).join('')}
                </ul>
            </div>
            
            <div class="analysis-category">
                <h3 class="category-title">
                    <span class="category-icon">🔧</span>
                    Skills Analysis
                </h3>
                <p><strong>Skills detected in your resume:</strong></p>
                <div class="skills-list">
                    ${data.skills.detected.map(skill => 
                        `<span class="skill-tag">${this.escapeHtml(skill)}</span>`
                    ).join('')}
                </div>
                ${data.skills.missing.length > 0 ? `
                    <p style="margin-top: 1rem;"><strong>Recommended skills to add:</strong></p>
                    <div class="skills-list">
                        ${data.skills.missing.map(skill => 
                            `<span class="skill-tag missing">${this.escapeHtml(skill)}</span>`
                        ).join('')}
                    </div>
                ` : ''}
            </div>
            
            ${data.jobMatch ? `
                <div class="analysis-category">
                    <h3 class="category-title">
                        <span class="category-icon">🎯</span>
                        Job Match Analysis
                    </h3>
                    <p><strong>Match with target job: ${data.jobMatch.score}%</strong></p>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${data.jobMatch.score}%"></div>
                    </div>
                    <p>${data.jobMatch.feedback}</p>
                    ${data.jobMatch.suggestions.length > 0 ? `
                        <ul class="suggestion-list" style="margin-top: 1rem;">
                            ${data.jobMatch.suggestions.map(suggestion => 
                                `<li class="suggestion-item warning">${this.escapeHtml(suggestion)}</li>`
                            ).join('')}
                        </ul>
                    ` : ''}
                </div>
            ` : ''}
        `;
    }

    showError(message) {
        alert('Error: ' + message); // In production, use a better error display
    }

    escapeHtml(unsafe) {
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    loadSavedData() {
        const savedJobDescription = localStorage.getItem('resumeAnalyzer_jobDescription');
        if (savedJobDescription) {
            this.jobDescription.value = savedJobDescription;
        }
    }

    saveJobDescription() {
        localStorage.setItem('resumeAnalyzer_jobDescription', this.jobDescription.value);
    }

    saveAnalysisHistory(analysis) {
        const history = JSON.parse(localStorage.getItem('resumeAnalyzer_history') || '[]');
        history.unshift({
            timestamp: new Date().toISOString(),
            score: analysis.overallScore,
            jobDescription: this.jobDescription.value.substring(0, 100) + '...'
        });
        
        if (history.length > 10) {
            history.pop();
        }
        
        localStorage.setItem('resumeAnalyzer_history', JSON.stringify(history));
    }
}

// Additional utility functions
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new ResumeAnalyzer();
    
    // Add some helpful console messages
    console.log('🚀 Resume Analyzer initialized');
    console.log('💡 Tip: Add a job description for tailored recommendations');
});